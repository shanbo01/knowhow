/**
 * The live step feed thumbnail always shows the full, uncropped screenshot
 * (matching what the app editor starts with): no automatic zoom-to-click
 * framing. The click ring is still drawn at its true position over the full
 * frame so the highlighted control stays visible without cropping anything.
 */
function contextualCrop() {
  return { x: 0, y: 0, width: 1, height: 1 };
}

function finitePositive(value, fallback = 1) {
  const numeric = Number(value);
  return Number.isFinite(numeric) && numeric > 0 ? numeric : fallback;
}

function imageRevision(step) {
  const blob = step?.imageBlob;
  if (!(blob instanceof Blob) && typeof step?.previewRevision === "string") {
    return step.previewRevision;
  }
  return [
    step?.updatedAt || step?.capturedAt || "",
    blob?.size || 0,
    blob?.type || "",
    step?.imageWidth || 0,
    step?.imageHeight || 0,
  ].join("|");
}

function positiveInteger(value, fallback) {
  const numeric = Number(value);
  return Number.isInteger(numeric) && numeric > 0 ? numeric : fallback;
}

function nonNegativeLimit(value, fallback) {
  const numeric = Number(value);
  return Number.isFinite(numeric) && numeric >= 0 ? numeric : fallback;
}

function withoutPreviewBlob(step) {
  if (!(step?.imageBlob instanceof Blob)) return step;
  const metadata = { ...step };
  delete metadata.imageBlob;
  return {
    ...metadata,
    previewRevision: imageRevision(step),
  };
}

export function orderedSteps(steps = []) {
  return [...steps].sort((left, right) => {
    const orderDelta = Number(left?.order || 0) - Number(right?.order || 0);
    if (orderDelta) return orderDelta;
    return String(left?.capturedAt || "").localeCompare(
      String(right?.capturedAt || ""),
    );
  });
}

export function createRefreshGate() {
  let latest = 0;
  return {
    next() {
      latest += 1;
      return latest;
    },
    isCurrent(token) {
      return token === latest;
    },
  };
}

export function liveFeedVisible(state) {
  return Boolean(state?.sessionId) &&
    ["recording", "paused"].includes(state.status);
}

export function createCapturedStepCache({
  getSteps,
  getStep,
  listSteps,
  maxBatchSize = 24,
  maxRetainedBlobs = 12,
  maxRetainedBlobBytes = 48 * 1024 * 1024,
}) {
  if (
    (typeof getSteps !== "function" && typeof getStep !== "function") ||
    typeof listSteps !== "function"
  ) {
    throw new TypeError("Step cache requires batch and legacy capture readers.");
  }
  const batchSize = positiveInteger(maxBatchSize, 24);
  const retainedBlobLimit = nonNegativeLimit(maxRetainedBlobs, 12);
  const retainedByteLimit = nonNegativeLimit(
    maxRetainedBlobBytes,
    48 * 1024 * 1024,
  );
  const readBatch =
    typeof getSteps === "function"
      ? getSteps
      : async (sessionId, stepIds) =>
          Promise.all(stepIds.map((stepId) => getStep(sessionId, stepId)));

  const sessions = new Map();

  function sessionCache(sessionId) {
    let cache = sessions.get(sessionId);
    if (!cache) {
      cache = {
        steps: new Map(),
        pending: new Map(),
        legacyPromise: null,
        batchTail: Promise.resolve(),
        previewOrder: [],
      };
      sessions.set(sessionId, cache);
    }
    return cache;
  }

  function enforcePreviewBudget(cache) {
    const retained = new Set();
    let retainedCount = 0;
    let retainedBytes = 0;
    for (const stepId of [...cache.previewOrder].reverse()) {
      const step = cache.steps.get(stepId);
      if (
        !step ||
        step.sourceEvent === "navigation" ||
        !(step.imageBlob instanceof Blob)
      ) {
        continue;
      }
      const size = Math.max(0, Number(step.imageBlob.size) || 0);
      if (
        retainedCount >= retainedBlobLimit ||
        retainedBytes + size > retainedByteLimit
      ) {
        continue;
      }
      retained.add(stepId);
      retainedCount += 1;
      retainedBytes += size;
    }
    for (const [stepId, step] of cache.steps) {
      if (step?.imageBlob instanceof Blob && !retained.has(stepId)) {
        cache.steps.set(stepId, withoutPreviewBlob(step));
      }
    }
  }

  function queueBatch(cache, sessionId, stepIds) {
    const run = cache.batchTail.then(async () => {
      const steps = await readBatch(sessionId, stepIds);
      for (const step of steps || []) {
        if (step?.id && stepIds.includes(step.id)) {
          cache.steps.set(step.id, step);
        }
      }
      enforcePreviewBudget(cache);
    });
    cache.batchTail = run.catch(() => undefined);
    for (const stepId of stepIds) {
      let pending;
      pending = run
        .then(() => cache.steps.get(stepId) || null)
        .finally(() => {
          if (cache.pending.get(stepId) === pending) {
            cache.pending.delete(stepId);
          }
        });
      cache.pending.set(stepId, pending);
    }
  }

  async function loadMissing(cache, sessionId, stepIds) {
    const missing = stepIds.filter(
      (stepId) => !cache.steps.has(stepId) && !cache.pending.has(stepId),
    );
    for (let offset = 0; offset < missing.length; offset += batchSize) {
      queueBatch(cache, sessionId, missing.slice(offset, offset + batchSize));
    }
    await Promise.all(
      stepIds.map((stepId) =>
        cache.steps.has(stepId)
          ? cache.steps.get(stepId)
          : cache.pending.get(stepId),
      ),
    );
  }

  async function loadLegacy(cache, sessionId) {
    if (!cache.legacyPromise) {
      cache.legacyPromise = Promise.resolve(listSteps(sessionId)).then(
        (steps) => {
          for (const step of steps || []) {
            if (step?.id) cache.steps.set(step.id, step);
          }
          cache.previewOrder = orderedSteps(cache.steps.values()).map(
            (step) => step.id,
          );
          enforcePreviewBudget(cache);
        },
      ).catch((error) => {
        cache.legacyPromise = null;
        throw error;
      });
    }
    await cache.legacyPromise;
  }

  return {
    async load(state) {
      const sessionId = state?.sessionId;
      if (!sessionId) return [];
      const cache = sessionCache(sessionId);

      if (Array.isArray(state.stepIds)) {
        const stepIds = [
          ...new Set(
            state.stepIds.filter(
              (stepId) => typeof stepId === "string" && stepId,
            ),
          ),
        ];
        cache.previewOrder = stepIds;
        await loadMissing(cache, sessionId, stepIds);
        if (
          Number.isInteger(state.stepCount) &&
          state.stepCount !== stepIds.length
        ) {
          await loadLegacy(cache, sessionId);
          const ordered = orderedSteps(cache.steps.values());
          cache.previewOrder = ordered.map((step) => step.id);
          enforcePreviewBudget(cache);
          return ordered;
        }
        enforcePreviewBudget(cache);
        return stepIds
          .map((stepId) => cache.steps.get(stepId))
          .filter(Boolean);
      }

      await loadLegacy(cache, sessionId);
      const ordered = orderedSteps(cache.steps.values());
      cache.previewOrder = ordered.map((step) => step.id);
      enforcePreviewBudget(cache);
      return ordered;
    },

    stats(sessionId) {
      const cache = sessions.get(sessionId);
      if (!cache) {
        return { steps: 0, pending: 0, retainedBlobs: 0, retainedBlobBytes: 0 };
      }
      let retainedBlobs = 0;
      let retainedBlobBytes = 0;
      for (const step of cache.steps.values()) {
        if (!(step?.imageBlob instanceof Blob)) continue;
        retainedBlobs += 1;
        retainedBlobBytes += Math.max(0, Number(step.imageBlob.size) || 0);
      }
      return {
        steps: cache.steps.size,
        pending: cache.pending.size,
        retainedBlobs,
        retainedBlobBytes,
      };
    },

    clear(sessionId) {
      if (sessionId) sessions.delete(sessionId);
      else sessions.clear();
    },
  };
}

export function createThumbnailUrlCache(
  urlApi = URL,
  { maxEntries = 12, maxBlobBytes = 48 * 1024 * 1024 } = {},
) {
  const entries = new Map();
  const entryLimit = nonNegativeLimit(maxEntries, 12);
  const byteLimit = nonNegativeLimit(maxBlobBytes, 48 * 1024 * 1024);
  let retainedBytes = 0;

  function release(stepId) {
    const entry = entries.get(stepId);
    if (!entry) return;
    urlApi.revokeObjectURL(entry.url);
    retainedBytes -= entry.size;
    entries.delete(stepId);
  }

  function enforceLimits() {
    while (
      entries.size > entryLimit ||
      retainedBytes > byteLimit
    ) {
      const oldestStepId = entries.keys().next().value;
      if (oldestStepId === undefined) break;
      release(oldestStepId);
    }
  }

  return {
    get(step) {
      if (!step?.id || !(step.imageBlob instanceof Blob)) return null;
      const revision = imageRevision(step);
      const current = entries.get(step.id);
      if (current?.revision === revision) {
        entries.delete(step.id);
        entries.set(step.id, current);
        return current.url;
      }
      release(step.id);
      const size = Math.max(0, Number(step.imageBlob.size) || 0);
      if (entryLimit === 0 || size > byteLimit) return null;
      const url = urlApi.createObjectURL(step.imageBlob);
      entries.set(step.id, { revision, size, url });
      retainedBytes += size;
      enforceLimits();
      return entries.has(step.id) ? url : null;
    },

    prune(stepIds) {
      const retained = new Set(stepIds);
      for (const stepId of entries.keys()) {
        if (!retained.has(stepId)) release(stepId);
      }
      enforceLimits();
    },

    stats() {
      return { entries: entries.size, retainedBlobBytes: retainedBytes };
    },

    dispose() {
      for (const stepId of [...entries.keys()]) release(stepId);
    },
  };
}

export function stepCopy(step) {
  if (step?.sourceEvent === "navigation") {
    const url = String(step.sanitizedUrl || "").trim();
    return {
      title: url ? "Navigate to " + url : "Navigate to the next page",
      detail: "",
    };
  }

  const title = String(step?.title || "Captured action").trim();
  const instructions = String(step?.instructions || "").trim();
  return {
    title,
    detail: instructions && instructions !== title ? instructions : "",
  };
}

export function projectClickToCrop(clickTarget, crop) {
  if (!clickTarget || !crop) return null;
  const x = Number(clickTarget.x);
  const y = Number(clickTarget.y);
  if (
    !Number.isFinite(x) ||
    !Number.isFinite(y) ||
    x < crop.x ||
    x > crop.x + crop.width ||
    y < crop.y ||
    y > crop.y + crop.height
  ) {
    return null;
  }
  return {
    x: (x - crop.x) / crop.width,
    y: (y - crop.y) / crop.height,
    color: clickTarget.color,
  };
}

export function thumbnailGeometry(step) {
  const crop = contextualCrop(step);
  const clickTarget =
    step?.sourceEvent === "navigation"
      ? null
      : projectClickToCrop(step?.clickTarget || null, crop);
  const imageWidth = finitePositive(step?.imageWidth);
  const imageHeight = finitePositive(step?.imageHeight);

  return {
    crop,
    clickTarget,
    aspectRatio: (imageWidth * crop.width) / (imageHeight * crop.height),
    image: {
      // The "+ 0" normalizes the -0 that (-0 / n) * 100 would otherwise
      // produce when crop.x/crop.y are exactly 0 (the common, un-cropped case).
      left: ((-crop.x / crop.width) * 100) + 0,
      top: ((-crop.y / crop.height) * 100) + 0,
      width: (1 / crop.width) * 100,
      height: (1 / crop.height) * 100,
    },
  };
}

export function feedRevision(sessionId, steps) {
  return [
    sessionId || "",
    ...steps.map((step) =>
      [
        step.id,
        step.order,
        step.sourceEvent,
        step.title,
        step.instructions,
        step.sanitizedUrl,
        imageRevision(step),
      ].join(":"),
    ),
  ].join("|");
}
